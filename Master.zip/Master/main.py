from customtkinter import *
import numpy as np
import cv2
import mediapipe as mp
from threading import Thread
from PIL import Image, ImageTk,ImageDraw
set_appearance_mode("Dark")


class VideoCapture:
    def __init__(self) -> None:
        mp_drawing = mp.solutions.drawing_utils
        mp_drawing_styles = mp.solutions.drawing_styles
        mp_face_mesh = mp.solutions.face_mesh
        drawing_spec = mp_drawing.DrawingSpec(thickness=1, circle_radius=1)

        self.cap = cv2.VideoCapture(0)
    def start_capture(self):
        #success, image = self.cap.read()
        while self.cap.isOpened():
            print("image")
            self.get_image()
            # success, image = self.cap.read()
            # if not success:
            #     print("Ignoring empty camera frame.")
            #     # If loading a video, use 'break' instead of 'continue'.
            #     continue
            # image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            #cv2.imshow('MediaPipe Face Mesh', image)
    def get_image(self):
        success, image = self.cap.read()
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        im = Image.fromarray(image)
        im = add_corners(im,10)
        imgtk = ImageTk.PhotoImage(image=im.resize((500,400))) 
        return imgtk

def add_corners(im, rad):
    circle = Image.new('L', (rad * 2, rad * 2), 0)
    draw = ImageDraw.Draw(circle)
    draw.ellipse((0, 0, rad * 2 - 1, rad * 2 - 1), fill=255)
    alpha = Image.new('L', im.size, 255)
    w, h = im.size
    alpha.paste(circle.crop((0, 0, rad, rad)), (0, 0))
    alpha.paste(circle.crop((0, rad, rad, rad * 2)), (0, h - rad))
    alpha.paste(circle.crop((rad, 0, rad * 2, rad)), (w - rad, 0))
    alpha.paste(circle.crop((rad, rad, rad * 2, rad * 2)), (w - rad, h - rad))
    im.putalpha(alpha)
    return im

class App(CTk):
    def __init__(self):
        super().__init__()
        self.title("Sensor Dashboard")
        self.geometry(f"{1300}x{780}")
        self.resizable(False,False)
        camera_obj = VideoCapture()

        # camera_thread = Thread(target=camera_obj.start_capture)
        # camera_thread.setDaemon(True)
        # camera_thread.start()
        
        


        controls_frame = CTkFrame(self,width=250)
        main_frame = CTkFrame(self)

        cam_frame = CTkFrame(main_frame)
        #cam_frame.pack_propagate(0)
        
        
        cam_label = CTkLabel(cam_frame,image=camera_obj.get_image(),width=500,height=400,text=None)
        cam_label.pack(expand=True,fill="both")





        controls_frame.pack(side="left",fill="y",padx=10,pady=10)
        main_frame.pack(fill="both",expand=True,padx=10,pady=10)
        cam_frame.grid(column=0,row=0,padx=10,pady=10)


if __name__ == "__main__":
    app = App()
    app.mainloop()